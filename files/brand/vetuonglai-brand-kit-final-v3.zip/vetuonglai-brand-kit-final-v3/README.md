# Vetuonglai Brand Kit Final v3

Direction: tech-luxury final

Locked contact block:
- Trần Hà Tâm
- Founder
- tranhatam@gmail.com
- vetuonglai.com
- @tranhatam

Included:
- logo system (primary, dark, mono, secondary, symbol, monogram, favicon)
- brand book PDF
- symbol rationale PDF
- business card PDF
- letterhead PDF
- web email signature
- hero and OG sample
- social launch post

Notes:
- This round pushes the identity colder, sharper, and more premium.
- Phone number and legal address were intentionally not added because they were not verified in the working context.
